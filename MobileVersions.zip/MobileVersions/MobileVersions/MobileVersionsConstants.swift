//
//  MobileVersionsConstants.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/20/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

enum MobileVersionsConstants {
    
    enum Strings {
        static let message_new_update_available = "¿Desea actualizar la aplicación?"
        
        static let message_new_update_mandatory = "Debe actualizar para poder utilizar la aplicación"
    }
}
