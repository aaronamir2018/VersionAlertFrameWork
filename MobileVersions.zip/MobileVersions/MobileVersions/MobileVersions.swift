//
//  MobileVersions.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import UIKit

public protocol MobileVersionsDelegate : NSObjectProtocol {
    func noUpdateNeeded()
}

public class MobileVersions {
    
    public class func getLatestVersion(
        viewController: UIViewController,
        nibName: String = "MobileVersionDialogViewController",
        bundle: Bundle = Bundle(for: MobileVersions.self),
        projectName project: String,
        environment: Environment = .production,
        storeparam : AppStoreParameters,
        delegate: MobileVersionsDelegate) {
        
        let checkUpdater = MobileVersionCheckUpdate(networkManager: NetworkManager.shared)
        checkUpdater.execute(projectName: project,
                             identifier: Bundle.main.bundleIdentifier!,
                             environment: environment,
                             state: .release) { status in
            switch status {
            case .newVersionAvailable(let versionUpdate):
                let vc = MobileVersionDialogViewController(versionUpdate: versionUpdate,appStore: storeparam, nibName: nibName, bundle: bundle)
                vc.delegate = delegate
                viewController.present(vc, animated: true, completion: nil)
            case .newVersionAvailableRequired(let versionUpdate):
                let vc = MobileVersionDialogViewController(versionUpdate: versionUpdate,appStore: storeparam ,nibName: nibName, bundle: bundle)
                vc.delegate = delegate
                viewController.present(vc, animated: true, completion: nil)
            case .latestVersion:
                delegate.noUpdateNeeded()
            case .error(let message):
                print("MobileVersions Error: \(message)")
                delegate.noUpdateNeeded()
            }
        }
    }

    
    
}
