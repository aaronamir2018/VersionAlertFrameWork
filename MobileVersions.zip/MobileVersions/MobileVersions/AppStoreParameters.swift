//
//  AppStoreParameters.swift
//  MobileVersions
//
//  Created by Aaron Cordero on 22/05/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

public struct AppStoreParameters{
    
    let appName: String
    let appID: String
    
    public init(appName: String, appID: String){
        
        self.appName = appName
        self.appID = appID
        
    }

}

