//
//  MobileVersions.h
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MobileVersions.
FOUNDATION_EXPORT double MobileVersionsVersionNumber;

//! Project version string for MobileVersions.
FOUNDATION_EXPORT const unsigned char MobileVersionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MobileVersions/PublicHeader.h>


