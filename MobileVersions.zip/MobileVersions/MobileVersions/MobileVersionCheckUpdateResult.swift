//
//  MobileVersionCheckUpdateState.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

enum MobileVersionCheckUpdateResult {
    case newVersionAvailable(versionUpdate: VersionUpdate)
    case newVersionAvailableRequired(versionUpdate: VersionUpdate)
    case latestVersion
    case error(message: String)
}
