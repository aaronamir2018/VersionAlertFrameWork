//
//  Environment.swift
//  MobileVersions
//
//  Created by Hugo Ángeles Chávez on 5/19/18.
//  Copyright © 2018 Hugo Ángeles Chávez. All rights reserved.
//

import Foundation

public enum Environment : String {
    case production = "production"
    case testflight = "testflight"
    
    
}
